from parse_tools import *
import sys
from log_util import *
#key: (ip,country), value: frequency
ip_country_dict = {} 

#print sys.argv

#f = open(sys.argv[1],'r')

'''
The plan is to use DirWalker to yield line of log in each file
'''

w = LogWalker(sys.argv[1], 'db33_34_swdf')
#    print "******"
#    print line
#    print "******"
for log in w:
    print log
    (haship,country) = log['hashIP'],log['country']
    if ip_country_dict.has_key((haship, country)):
        ip_country_dict[(haship,country)] += 1
    else:
        ip_country_dict[(haship,country)] = 1

print 'total:',sum(ip_country_dict.values())

for k,v in ip_country_dict.items():
    print k, v
    
    #for k,v in fields.items():
        #print k,":",v
        